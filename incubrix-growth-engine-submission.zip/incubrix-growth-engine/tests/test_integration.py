"""
tests/test_integration.py
End-to-end integration tests verifying pipeline orchestration,
incremental refresh without duplicate pollution, and failure recovery.
"""

import os
import pytest
from main import run_pipeline
from engine.refresh import RefreshEngine
from engine.logger import get_all_runs, get_seed_logs

def test_full_pipeline_run_integration(tmp_path):
    result = run_pipeline(
        input_file="data/sample_leads.csv",
        run_type="TEST_NORMAL",
        run_id="TEST_RUN_001",
        priority_a_cap=25,
        execute_seed_test=True
    )

    assert result["status"] == "SUCCESS"
    assert result["qualified_count"] >= 1000
    assert result["priority_a_count"] == 25
    assert result["duplicates_removed"] > 0
    assert result["portfolio_audit"]["valid"] is True
    assert os.path.exists(result["export_paths"]["leads"])
    assert os.path.exists(result["export_paths"]["submission_workbook"])

def test_refresh_deduplication_without_pollution():
    refresher = RefreshEngine(master_csv_path="data/output/leads.csv")
    result = refresher.run_refresh(
        new_input_path="data/sample_leads.csv",
        run_id="TEST_REFRESH_001"
    )

    assert result["status"] == "SUCCESS"
    assert result["duplicates_removed"] > 0
    assert result["qualified_count"] >= 1000

def test_failure_recovery_on_corrupt_file():
    refresher = RefreshEngine()
    result = refresher.run_refresh(
        new_input_path="data/non_existent_corrupted.csv",
        run_id="TEST_FAIL_001"
    )

    assert result["status"] == "FAILED"
    assert "error" in result

def test_priority_a_complete_three_channel_sequences():
    """Verifies that all 25 Priority A leads have 3 files and each file has STEP 1, STEP 2, STEP 3."""
    channels = ["email", "linkedin", "youtube"]
    for ch in channels:
        ch_dir = os.path.join("outreach", ch)
        assert os.path.exists(ch_dir)
        files = [f for f in os.listdir(ch_dir) if f.endswith(".txt")]
        assert len(files) == 25, f"Expected 25 sequence files in {ch_dir}, found {len(files)}"
        for f in files:
            content = open(os.path.join(ch_dir, f), "r", encoding="utf-8").read()
            assert "STEP 1" in content, f"Missing STEP 1 in {f}"
            assert "STEP 2" in content, f"Missing STEP 2 in {f}"
            assert "STEP 3" in content, f"Missing STEP 3 in {f}"
