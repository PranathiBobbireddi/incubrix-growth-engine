"""
tests/test_scoring.py
Unit tests verifying the 100-point transparent rubric and Priority A/B/C assignment.
"""

import pytest
from engine.scoring import LeadScorer

@pytest.fixture
def scorer():
    return LeadScorer(reference_date="2026-11-23")

@pytest.fixture
def base_lead():
    return {
        "lead_id": "TEST_SCORE_01",
        "creator_name": "Sarah Vance",
        "creator_segment": "podcaster",
        "country_iso2": "US",
        "primary_language": "en",
        "primary_platform": "YouTube",
        "profile_url": "https://www.youtube.com/@sarah_pod",
        "stable_creator_id": "ID_001",
        "followers_or_subscribers": 120000,
        "last_content_date": "2026-11-21",  # Recent (within 7 days)
        "recent_content_url": "https://www.youtube.com/watch?v=123",
        "content_count_30d": 18,            # High (>= 16)
        "longform_count_60d": 5,            # Strong (>= 4)
        "monetization_signal": "Sponsorships and Paid Masterclasses",
        "monetization_evidence_url": "https://patreon.com/sarah",
        "incubrix_need": "Repurposing 45-min podcast episodes into vertical shorts",
        "need_evidence_url": "https://youtube.com/post_123",
        "best_channel": "Email",
        "channel_handle_or_url": "sarah@creatorhq.com",
        "channel_evidence_url": "https://youtube.com/@sarah_pod/about",
        "backup_channel": "LinkedIn",
        "candidate_status": "QUALIFIED"
    }

def test_high_lead_scoring_breakdown(scorer, base_lead):
    scored = scorer.calculate_lead_score(base_lead)
    score = scored["lead_score"]
    assert 75 <= score <= 100
    assert "Activity:" in scored["score_explanation"]
    assert "Commercial:" in scored["score_explanation"]
    assert "ProductFit:" in scored["score_explanation"]
    assert "Reachability:" in scored["score_explanation"]
    assert "Evidence:" in scored["score_explanation"]

def test_priority_a_capping(scorer, base_lead):
    # Create 50 high-scoring leads
    leads = []
    for i in range(50):
        lead = dict(base_lead, lead_id=f"L_{i}", candidate_status="QUALIFIED")
        leads.append(scorer.calculate_lead_score(lead))

    prioritized = scorer.assign_priorities(leads, priority_a_cap=25)
    priority_a_leads = [l for l in prioritized if l.get("priority") == "A"]
    priority_b_leads = [l for l in prioritized if l.get("priority") == "B"]

    assert len(priority_a_leads) == 25
    assert len(priority_b_leads) == 25
    for l in priority_a_leads:
        assert l["priority"] == "A"

def test_rejected_leads_assigned_priority_c(scorer, base_lead):
    rejected_lead = dict(base_lead, candidate_status="REJECTED")
    scored = scorer.calculate_lead_score(rejected_lead)
    prioritized = scorer.assign_priorities([scored], priority_a_cap=25)
    assert prioritized[0]["priority"] == "C"
