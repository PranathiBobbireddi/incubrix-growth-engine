"""
tests/test_validator.py
Unit tests verifying Criteria A through F qualification rules and portfolio constraints.
"""

import pytest
from engine.validator import LeadValidator

@pytest.fixture
def validator():
    return LeadValidator(reference_date="2026-11-23")

@pytest.fixture
def valid_lead():
    return {
        "lead_id": "TEST_001",
        "creator_name": "Elena Sinclair",
        "creator_segment": "podcaster",
        "country_iso2": "US",
        "primary_language": "en",
        "primary_platform": "YouTube",
        "profile_url": "https://www.youtube.com/@elena_podcast",
        "stable_creator_id": "ID_YT_001",
        "followers_or_subscribers": 45000,
        "last_content_date": "2026-11-20",
        "recent_content_url": "https://www.youtube.com/watch?v=ep123",
        "content_count_30d": 10,
        "longform_count_60d": 4,
        "monetization_signal": "Sponsorships and Patreon",
        "monetization_evidence_url": "https://www.patreon.com/elena",
        "incubrix_need": "Short-form video clipping backlog",
        "need_evidence_url": "https://www.youtube.com/post_01",
        "best_channel": "Email",
        "channel_handle_or_url": "elena@podcasthq.com",
        "channel_evidence_url": "https://www.youtube.com/@elena_podcast/about",
        "backup_channel": "LinkedIn",
        "checked_date": "2026-11-22"
    }

def test_valid_lead_qualifies(validator, valid_lead):
    evaluated = validator.evaluate_lead(valid_lead)
    assert evaluated["candidate_status"] == "QUALIFIED"
    assert evaluated["rejection_reason"] == ""
    assert evaluated["completeness_check"] == "VERIFIED"

def test_reject_inactive_creator(validator, valid_lead):
    valid_lead["last_content_date"] = "2026-08-01"  # > 60 days
    evaluated = validator.evaluate_lead(valid_lead)
    assert evaluated["candidate_status"] == "REJECTED"
    assert "Criterion B Failed" in evaluated["rejection_reason"]

def test_reject_low_content_frequency(validator, valid_lead):
    valid_lead["content_count_30d"] = 2
    valid_lead["longform_count_60d"] = 1
    evaluated = validator.evaluate_lead(valid_lead)
    assert evaluated["candidate_status"] == "REJECTED"
    assert "Criterion B Failed" in evaluated["rejection_reason"]

def test_reject_excluded_segment_agency(validator, valid_lead):
    valid_lead["creator_segment"] = "agency"
    evaluated = validator.evaluate_lead(valid_lead)
    assert evaluated["candidate_status"] == "REJECTED"
    assert "Criterion A Failed" in evaluated["rejection_reason"]

def test_reject_non_approved_country(validator, valid_lead):
    valid_lead["country_iso2"] = "DE"
    evaluated = validator.evaluate_lead(valid_lead)
    assert evaluated["candidate_status"] == "REJECTED"
    assert "Criterion A Failed" in evaluated["rejection_reason"]

def test_reject_missing_monetization_evidence(validator, valid_lead):
    valid_lead["monetization_evidence_url"] = ""
    evaluated = validator.evaluate_lead(valid_lead)
    assert evaluated["candidate_status"] == "REJECTED"
    assert "Criterion C Failed" in evaluated["rejection_reason"]

def test_reject_missing_need_evidence(validator, valid_lead):
    valid_lead["need_evidence_url"] = ""
    evaluated = validator.evaluate_lead(valid_lead)
    assert evaluated["candidate_status"] == "REJECTED"
    assert "Criterion D Failed" in evaluated["rejection_reason"]

def test_reject_stale_checked_date(validator, valid_lead):
    valid_lead["checked_date"] = "2026-09-01"  # > 30 days old
    evaluated = validator.evaluate_lead(valid_lead)
    assert evaluated["candidate_status"] == "REJECTED"
    assert "Criterion F Failed" in evaluated["rejection_reason"]

def test_portfolio_constraints_valid(validator, valid_lead):
    leads = [
        dict(valid_lead, lead_id=f"L_{i}", country_iso2=c, candidate_status="QUALIFIED")
        for i, c in enumerate(["US", "US", "GB", "CA", "AU", "US", "GB", "SG", "IE", "NZ"])
    ]
    audit = validator.audit_portfolio_constraints(leads)
    assert audit["valid"] is True
    assert audit["approved_country_ratio"] == 1.0
    assert audit["distinct_countries"] >= 3
    assert audit["max_single_country_ratio"] <= 0.60
