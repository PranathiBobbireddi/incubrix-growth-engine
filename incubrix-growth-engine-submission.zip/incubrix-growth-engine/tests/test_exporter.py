"""
tests/test_exporter.py
Unit tests verifying strict 30-column CSV ordering, UTF-8 encoding, zero DEMO leak,
and official 5-tab Excel submission workbook generation.
"""

import os
import csv
import pytest
import openpyxl
from engine.exporter import LeadExporter, EXACT_30_COLUMNS

@pytest.fixture
def exporter(tmp_path):
    return LeadExporter(output_dir=str(tmp_path))

@pytest.fixture
def sample_records():
    return [
        {
            "lead_id": "LEAD_0001",
            "creator_name": "Liam Kearney",
            "creator_segment": "podcaster",
            "country_iso2": "US",
            "primary_language": "en",
            "primary_platform": "YouTube",
            "profile_url": "https://youtube.com/@liam",
            "stable_creator_id": "ID_01",
            "followers_or_subscribers": 50000,
            "last_content_date": "2026-11-20",
            "recent_content_url": "https://youtube.com/watch?v=1",
            "content_count_30d": 12,
            "longform_count_60d": 3,
            "monetization_signal": "Sponsorships",
            "monetization_evidence_url": "https://patreon.com/liam",
            "incubrix_need": "Shorts clipping",
            "need_evidence_url": "https://youtube.com/post_1",
            "best_channel": "Email",
            "channel_handle_or_url": "liam@mail.com",
            "channel_evidence_url": "https://youtube.com/about",
            "backup_channel": "LinkedIn",
            "personalization_hook": "Great episode",
            "first_message": "Hi Liam",
            "checked_date": "2026-11-21",
            "priority": "A",
            "lead_score": 85,
            "candidate_status": "QUALIFIED",
            "rejection_reason": "",
            "duplicate_check": "PASSED",
            "completeness_check": "VERIFIED"
        },
        {
            "lead_id": "DEMO_TEST_99",
            "creator_name": "DEMO Fake Lead",
            "candidate_status": "QUALIFIED",
            "is_demo": True
        }
    ]

def test_exact_30_columns_order_and_utf8(exporter, sample_records):
    out_csv = exporter.export_csv(sample_records, filename="test_leads.csv", filter_demo=False)
    assert os.path.exists(out_csv)

    with open(out_csv, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        headers = next(reader)
        assert headers == EXACT_30_COLUMNS
        assert len(headers) == 30

def test_zero_demo_records_in_official_export(exporter, sample_records):
    out_csv = exporter.export_csv(sample_records, filename="official_leads.csv", filter_demo=True)
    with open(out_csv, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
        assert len(rows) == 1
        assert rows[0]["lead_id"] == "LEAD_0001"
        assert all("DEMO" not in r["lead_id"] for r in rows)

def test_build_submission_workbook_sheets_and_formulas(exporter, sample_records, tmp_path):
    wb_path = str(tmp_path / "submission_test.xlsx")
    exporter.build_submission_workbook(sample_records, output_path=wb_path)
    assert os.path.exists(wb_path)

    wb = openpyxl.load_workbook(wb_path, data_only=False)
    expected_sheets = ["00_START", "01_INSIGHT", "02_LEADS", "03_ENGINE_LAUNCH", "04_SELF_CHECK"]
    assert wb.sheetnames == expected_sheets

    ws_leads = wb["02_LEADS"]
    headers = [cell.value for cell in ws_leads[4]]
    assert headers == EXACT_30_COLUMNS

def test_workbook_02_leads_matches_leads_csv_row_for_row(exporter, sample_records, tmp_path):
    """Verifies that 02_LEADS has exactly the same number of rows as the exported leads without truncation."""
    test_leads = sample_records * 5  # 10 records
    csv_path = exporter.export_csv(test_leads, filename="test_match.csv", filter_demo=False)
    wb_path = str(tmp_path / "test_match_wb.xlsx")
    exporter.build_submission_workbook(test_leads, output_path=wb_path)

    wb = openpyxl.load_workbook(wb_path, data_only=False)
    ws_leads = wb["02_LEADS"]

    # Read CSV rows
    with open(csv_path, "r", encoding="utf-8") as f:
        csv_rows = list(csv.DictReader(f))

    # Read non-empty data rows in 02_LEADS (rows 5+ where lead_id is present)
    wb_rows = []
    for r in range(5, ws_leads.max_row + 1):
        lead_id = ws_leads.cell(row=r, column=1).value
        if lead_id is not None and str(lead_id).strip() != "":
            row_vals = [ws_leads.cell(row=r, column=c).value for c in range(1, 31)]
            wb_rows.append(row_vals)

    assert len(wb_rows) == len(csv_rows)

def test_demo_and_production_data_separation(exporter):
    """Verifies that synthetic demo data is separated from production verified leads."""
    mixed_leads = [
        {"lead_id": "PROD_0001", "creator_name": "Lex Fridman", "candidate_status": "QUALIFIED", "is_demo": False},
        {"lead_id": "DEMO_LEAD_0001", "creator_name": "[DEMO] Alex Vance", "candidate_status": "DEMO_SYNTHETIC", "is_demo": True},
        {"lead_id": "DEMO_PENDING_0001", "creator_name": "[DEMO] Sarah Mercer", "candidate_status": "PENDING_VERIFICATION", "is_demo": True},
        {"lead_id": "DEMO_REJECT_0001", "creator_name": "[DEMO] David Sterling", "candidate_status": "REJECTED", "is_demo": True}
    ]
    bundles = exporter.export_all_bundles(mixed_leads)
    
    # Official leads.csv: strictly 0 DEMO
    with open(bundles["leads"], "r", encoding="utf-8") as f:
        official = list(csv.DictReader(f))
        assert len(official) == 1
        assert official[0]["lead_id"] == "PROD_0001"
        assert all("DEMO" not in r["lead_id"] for r in official)

    # demo_leads.csv: contains the demo records
    with open(bundles["demo_leads"], "r", encoding="utf-8") as f:
        demos = list(csv.DictReader(f))
        assert len(demos) >= 1
        assert any("DEMO" in r["lead_id"] for r in demos)

    # all_reviewed_leads.csv: contains all 4 categories
    with open(bundles["all_reviewed"], "r", encoding="utf-8") as f:
        all_rev = list(csv.DictReader(f))
        assert len(all_rev) == 4
