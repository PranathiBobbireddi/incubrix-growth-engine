"""
tests/test_deduplicator.py
Unit tests verifying multi-key deduplication and cross-source evidence merging.
"""

import pytest
from engine.deduplicator import LeadDeduplicator

@pytest.fixture
def deduplicator():
    return LeadDeduplicator()

def test_primary_key_deduplication(deduplicator):
    leads = [
        {
            "lead_id": "L1",
            "creator_name": "Marcus Thorne",
            "primary_platform": "YouTube",
            "stable_creator_id": "ID_YT_999",
            "profile_url": "https://youtube.com/@marcus",
            "followers_or_subscribers": 50000,
            "last_content_date": "2026-11-15",
            "best_channel": "Email",
            "channel_handle_or_url": "marcus@domain.com"
        },
        {
            "lead_id": "L2",
            "creator_name": "Marcus Thorne",
            "primary_platform": "YouTube",
            "stable_creator_id": "ID_YT_999",  # Identical primary key
            "profile_url": "https://youtube.com/@marcus",
            "followers_or_subscribers": 52000,  # Fresher metric
            "last_content_date": "2026-11-20",  # Fresher date
            "backup_channel": "LinkedIn"         # Enriched backup
        }
    ]

    deduped, removed_count = deduplicator.deduplicate(leads)
    assert len(deduped) == 1
    assert removed_count == 1
    merged = deduped[0]
    assert merged["followers_or_subscribers"] == 52000
    assert merged["last_content_date"] == "2026-11-20"
    assert merged["backup_channel"] == "LinkedIn"
    assert merged["duplicate_check"] == "PASSED_MERGED"

def test_secondary_key_canonical_url_deduplication(deduplicator):
    leads = [
        {
            "lead_id": "L1",
            "creator_name": "Sophia Gallagher",
            "primary_platform": "YouTube",
            "stable_creator_id": "ID_A",
            "profile_url": "https://www.youtube.com/@sophia_talks/?utm_source=share"
        },
        {
            "lead_id": "L2",
            "creator_name": "Sophia Gallagher",
            "primary_platform": "YouTube",
            "stable_creator_id": "ID_B",
            "profile_url": "http://youtube.com/@sophia_talks/"  # Canonical match
        }
    ]

    deduped, removed_count = deduplicator.deduplicate(leads)
    assert len(deduped) == 1
    assert removed_count == 1

def test_no_false_positive_deduplication(deduplicator):
    leads = [
        {
            "lead_id": "L1",
            "creator_name": "Alex Mercer",
            "primary_platform": "YouTube",
            "stable_creator_id": "ID_001",
            "profile_url": "https://youtube.com/@alex_m"
        },
        {
            "lead_id": "L2",
            "creator_name": "David Sterling",
            "primary_platform": "YouTube",
            "stable_creator_id": "ID_002",
            "profile_url": "https://youtube.com/@david_s"
        }
    ]

    deduped, removed_count = deduplicator.deduplicate(leads)
    assert len(deduped) == 2
    assert removed_count == 0
