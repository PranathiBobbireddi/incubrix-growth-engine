"""
engine/outreach_generator.py
Generates personalized, compliant 3-step outreach sequences for Priority A leads
across Email, LinkedIn, and YouTube, saving individual draft files and segment playbooks.
"""

import os
import re
import json
from typing import Dict, Any, List, Optional
from engine.logger import logger

DEFAULT_SENDER_NAME = "Pranathi Bobbireddi"
DEFAULT_SENDER_ROLE = "Growth Engineer at IncuBrix"
DEFAULT_OPT_OUT = "If you'd rather not hear from us about content workflow automation, reply 'stop' or click https://incubrix.com/unsubscribe."

class OutreachGenerator:
    """Generates hyper-personalized outreach sequences across channels."""

    def __init__(
        self,
        sender_name: str = DEFAULT_SENDER_NAME,
        sender_role: str = DEFAULT_SENDER_ROLE,
        opt_out_text: str = DEFAULT_OPT_OUT,
        base_dir: str = "outreach"
    ):
        self.sender_name = sender_name
        self.sender_role = sender_role
        self.opt_out_text = opt_out_text
        self.base_dir = base_dir

    @staticmethod
    def slugify(text: str) -> str:
        """Creates filesystem-safe filename slug."""
        text = re.sub(r"[^\w\s-]", "", str(text)).strip().lower()
        return re.sub(r"[-\s]+", "_", text)[:40]

    def build_personalization_hook(self, lead: Dict[str, Any]) -> str:
        """Creates specific observation hook mentioning recent content and workflow context."""
        creator = lead.get("creator_name", "Creator")
        segment = lead.get("creator_segment", "creator").replace("_", " ")
        recent_url = lead.get("recent_content_url", "")
        need = lead.get("incubrix_need", "scaling multi-platform video repurposing")

        hook = (
            f"Noticed your recent work as a {segment} on {lead.get('primary_platform', 'your channel')} "
            f"({recent_url}), particularly your deep dive and consistent delivery. "
            f"Given your focus on {need}, your production cadence is impressive."
        )
        return hook

    def generate_email_sequence(self, lead: Dict[str, Any]) -> Dict[str, str]:
        """Generates 3-step personalized email sequence."""
        creator = lead.get("creator_name", "Creator")
        hook = lead.get("personalization_hook") or self.build_personalization_hook(lead)
        need = lead.get("incubrix_need", "content repurposing bottlenecks")
        recent_url = lead.get("recent_content_url", "")

        first_msg = (
            f"Subject: Repurposing workflow for {creator}'s recent content\n\n"
            f"Hi {creator.split()[0]},\n\n"
            f"{hook}\n\n"
            f"At IncuBrix, we build AI-driven workflow engines that transform long-form content directly into high-performing short-form clips, automated chaptered summaries, and multi-channel publication assets—cutting turnaround from days to under 15 minutes.\n\n"
            f"We noticed that managing {need} can create a significant operational backlog. Would you be open to seeing a 2-minute custom sample we generated from {recent_url}?\n\n"
            f"Best regards,\n"
            f"{self.sender_name}\n"
            f"{self.sender_role}\n"
            f"IncuBrix Private Limited | https://www.incubrix.com\n\n"
            f"---\n{self.opt_out_text}"
        )

        followup_1 = (
            f"Subject: Re: Repurposing workflow for {creator}'s recent content\n\n"
            f"Hi {creator.split()[0]},\n\n"
            f"Following up briefly on my note earlier this week. I put together a quick preview of how IncuBrix automates speaker tracking, dynamic captions, and vertical reformatting specifically matched to your visual branding.\n\n"
            f"Our creator partners save 12-16 hours weekly while tripling their cross-platform reach across YouTube Shorts, LinkedIn, and TikTok.\n\n"
            f"Happy to send the private preview link if this aligns with your current priorities?\n\n"
            f"Best,\n"
            f"{self.sender_name}\n\n"
            f"---\n{self.opt_out_text}"
        )

        followup_2 = (
            f"Subject: Final check: Content pipeline automation for {creator}\n\n"
            f"Hi {creator.split()[0]},\n\n"
            f"I realize your schedule is packed producing great content. I won't crowd your inbox further.\n\n"
            f"If solving {need} or scaling your content backlog becomes a focus later this quarter, you can explore our creator workflows at https://www.incubrix.com/creators.\n\n"
            f"Wishing you continued growth!\n\n"
            f"Warmly,\n"
            f"{self.sender_name}\n"
            f"{self.sender_role}\n\n"
            f"---\n{self.opt_out_text}"
        )

        return {
            "first_message": first_msg,
            "followup_1": followup_1,
            "followup_2": followup_2
        }

    def generate_linkedin_sequence(self, lead: Dict[str, Any]) -> Dict[str, str]:
        """Generates 3-step personalized LinkedIn InMail / Message sequence."""
        creator = lead.get("creator_name", "Creator")
        first_name = creator.split()[0]
        need = lead.get("incubrix_need", "post-production workflow")

        first_msg = (
            f"Hi {first_name}, caught your recent breakdown on {lead.get('primary_platform', 'your profile')}. "
            f"I lead Growth Engineering at IncuBrix where we help high-output educators and podcasters automate "
            f"their clip repurposing and social distribution. Saw you handle {need}—curious if you've explored AI-assisted "
            f"turnaround to reclaim editing hours? Glad to share a 90-sec prototype."
        )

        followup_1 = (
            f"Hi {first_name}, following up on my previous note. We recently helped another creator in your niche "
            f"cut video turnaround by 75% without compromising editorial quality. Would you be open to taking a peek at a benchmark?"
        )

        followup_2 = (
            f"Hi {first_name}, totally understand if you're hands-full right now! Leaving the door open if content workflow "
            f"or repurposing ever becomes a bottleneck down the road. All the best with your upcoming releases."
        )

        return {
            "first_message": first_msg,
            "followup_1": followup_1,
            "followup_2": followup_2
        }

    def generate_youtube_sequence(self, lead: Dict[str, Any]) -> Dict[str, str]:
        """Generates 3-step personalized YouTube Business Inquiry sequence."""
        creator = lead.get("creator_name", "Creator")
        first_name = creator.split()[0]
        recent_url = lead.get("recent_content_url", "your latest video")
        need = lead.get("incubrix_need", "video editing and short-form repurposing")

        first_msg = (
            f"Inquiry: Content Workflow Partnership for {creator}\n\n"
            f"Hello {creator} Team,\n\n"
            f"Loved the production on {recent_url}. I'm reaching out from IncuBrix ({self.sender_name}, Growth Engineering). "
            f"We specialize in automated post-production workflows that convert full episodes into viral-ready vertical clips with accurate captions and b-roll inserts.\n\n"
            f"Since managing {need} is often the most time-consuming phase of scaling a YouTube channel, we'd love to generate a complimentary 3-clip package for your channel to demonstrate the speed and quality.\n\n"
            f"Where is the best place to send over the sample preview?"
        )

        followup_1 = (
            f"Re: Inquiry: Content Workflow Partnership for {creator}\n\n"
            f"Hello {creator} Team,\n\n"
            f"Quick follow up—our media processing pipeline just completed a benchmark for creators publishing at your cadence, yielding a 4x increase in Shorts impressions. Let me know if you'd like to test drive the clips."
        )

        followup_2 = (
            f"Closing loop: Content Workflow Partnership for {creator}\n\n"
            f"Hello {creator} Team,\n\n"
            f"Assuming now isn't the right time. We'll continue following your channel's success! If editing bandwidth ever tightens, feel free to reach back out."
        )

        return {
            "first_message": first_msg,
            "followup_1": followup_1,
            "followup_2": followup_2
        }

    def clean_outreach_dirs(self):
        """Cleans draft directories to ensure exact count matching current Priority A leads."""
        for ch in ["email", "linkedin", "youtube"]:
            d = os.path.join(self.base_dir, ch)
            if os.path.exists(d):
                for f in os.listdir(d):
                    p = os.path.join(d, f)
                    if os.path.isfile(p):
                        try:
                            os.remove(p)
                        except OSError:
                            pass

    def save_outreach_drafts(self, lead: Dict[str, Any]) -> Dict[str, str]:
        """Saves generated outreach sequences to disk under outreach/email, linkedin, and youtube."""
        lead_id = lead.get("lead_id", "LEAD")
        creator_name = lead.get("creator_name", "creator")
        slug = self.slugify(creator_name)
        filename = f"{lead_id}_{slug}.txt"

        email_seq = self.generate_email_sequence(lead)
        linkedin_seq = self.generate_linkedin_sequence(lead)
        youtube_seq = self.generate_youtube_sequence(lead)

        paths = {}

        # 1. Email Draft
        email_dir = os.path.join(self.base_dir, "email")
        os.makedirs(email_dir, exist_ok=True)
        email_path = os.path.join(email_dir, filename)
        with open(email_path, "w", encoding="utf-8") as f:
            f.write(f"=== EMAIL OUTREACH SEQUENCE FOR {creator_name} ({lead_id}) ===\n\n")
            f.write(f"--- STEP 1: INITIAL OUTREACH ---\n{email_seq['first_message']}\n\n")
            f.write(f"--- STEP 2: VALUE FOLLOW-UP (+4 DAYS) ---\n{email_seq['followup_1']}\n\n")
            f.write(f"--- STEP 3: BREAKUP NUDGE (+8 DAYS) ---\n{email_seq['followup_2']}\n")
        paths["email"] = email_path

        # 2. LinkedIn Draft
        li_dir = os.path.join(self.base_dir, "linkedin")
        os.makedirs(li_dir, exist_ok=True)
        li_path = os.path.join(li_dir, filename)
        with open(li_path, "w", encoding="utf-8") as f:
            f.write(f"=== LINKEDIN OUTREACH SEQUENCE FOR {creator_name} ({lead_id}) ===\n\n")
            f.write(f"--- STEP 1: INITIAL INMAIL ---\n{linkedin_seq['first_message']}\n\n")
            f.write(f"--- STEP 2: SOCIAL PROOF FOLLOW-UP ---\n{linkedin_seq['followup_1']}\n\n")
            f.write(f"--- STEP 3: CLOSING TOUCH ---\n{linkedin_seq['followup_2']}\n")
        paths["linkedin"] = li_path

        # 3. YouTube Draft
        yt_dir = os.path.join(self.base_dir, "youtube")
        os.makedirs(yt_dir, exist_ok=True)
        yt_path = os.path.join(yt_dir, filename)
        with open(yt_path, "w", encoding="utf-8") as f:
            f.write(f"=== YOUTUBE BUSINESS OUTREACH SEQUENCE FOR {creator_name} ({lead_id}) ===\n\n")
            f.write(f"--- STEP 1: BUSINESS INQUIRY ---\n{youtube_seq['first_message']}\n\n")
            f.write(f"--- STEP 2: SAMPLE CLIPS OFFER ---\n{youtube_seq['followup_1']}\n\n")
            f.write(f"--- STEP 3: FINAL TOUCH ---\n{youtube_seq['followup_2']}\n")
        paths["youtube"] = yt_path

        return paths

    def enrich_priority_a_lead(self, lead: Dict[str, Any]) -> Dict[str, Any]:
        """Generates hook and sequence, populates CSV columns, and saves drafts."""
        record = dict(lead)
        hook = self.build_personalization_hook(record)
        record["personalization_hook"] = hook

        best_channel = record.get("best_channel", "Email")
        if best_channel == "LinkedIn":
            seq = self.generate_linkedin_sequence(record)
        elif best_channel == "YouTube Business Contact":
            seq = self.generate_youtube_sequence(record)
        else:
            seq = self.generate_email_sequence(record)

        record["first_message"] = seq["first_message"]
        record["followup_1"] = seq["followup_1"]
        record["followup_2"] = seq["followup_2"]

        # Save files to disk
        self.save_outreach_drafts(record)
        return record
