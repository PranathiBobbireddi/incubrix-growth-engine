"""
engine/scoring.py
Transparent 100-point lead scoring model and Priority A/B/C assignment.
Evaluates Activity (20), Commercial (20), IncuBrix Fit (25), Reachability (15), and Evidence (20).
"""

from datetime import datetime
from typing import Dict, Any, List, Tuple
from engine.validator import LeadValidator

REFERENCE_DATE = "2026-11-23"

class LeadScorer:
    """Computes transparent granular rubric scores and assigns priority levels."""

    def __init__(self, reference_date: str = REFERENCE_DATE):
        self.ref_date = datetime.strptime(reference_date, "%Y-%m-%d")

    def score_activity(self, lead: Dict[str, Any]) -> Tuple[int, str]:
        """Max 20 Points: Frequency (10) + Recency (6) + Long-form Volume (4)."""
        score = 0
        notes = []

        count_30d = int(lead.get("content_count_30d", 0))
        if count_30d >= 16:
            score += 10
            notes.append("High publishing volume (16+ items/mo: +10)")
        elif count_30d >= 8:
            score += 7
            notes.append("Standard active publishing (8-15 items/mo: +7)")
        else:
            score += 3
            notes.append("Low publishing volume: +3")

        # Recency
        last_str = str(lead.get("last_content_date", "")).strip()
        if last_str:
            try:
                days = (self.ref_date - datetime.strptime(last_str, "%Y-%m-%d")).days
                if days <= 7:
                    score += 6
                    notes.append("Active within 7 days: +6")
                elif days <= 14:
                    score += 5
                    notes.append("Active within 14 days: +5")
                elif days <= 30:
                    score += 3
                    notes.append("Active within 30 days: +3")
                elif days <= 60:
                    score += 1
                    notes.append("Active within 60 days: +1")
            except ValueError:
                pass

        # Longform
        longform = int(lead.get("longform_count_60d", 0))
        if longform >= 4:
            score += 4
            notes.append("Strong long-form library (4+ episodes: +4)")
        elif longform >= 2:
            score += 2
            notes.append("Moderate long-form presence (2-3 episodes: +2)")

        score = min(20, score)
        return score, "; ".join(notes)

    def score_commercial(self, lead: Dict[str, Any]) -> Tuple[int, str]:
        """Max 20 Points: Sponsorships (8) + Courses/Products (8) + Monetization Signal Presence (4)."""
        score = 0
        notes = []
        signal = str(lead.get("monetization_signal", "")).lower()

        if "sponsor" in signal or "brand deal" in signal or "ad" in signal:
            score += 8
            notes.append("Verified commercial sponsorships: +8")
        if "course" in signal or "membership" in signal or "patreon" in signal or "product" in signal or "coaching" in signal:
            score += 8
            notes.append("Creator-owned products/courses/membership: +8")
        if "affiliate" in signal or "consulting" in signal or "newsletter" in signal:
            score += 4
            notes.append("Affiliate/consulting revenue streams: +4")

        # Base commercial presence if verified URL exists
        if LeadValidator.is_valid_url(lead.get("monetization_evidence_url")) and score < 12:
            score = max(score, 12)
            notes.append("Verified commercial evidence baseline: set to 12")

        score = min(20, score)
        return score, "; ".join(notes)

    def score_incubrix_fit(self, lead: Dict[str, Any]) -> Tuple[int, str]:
        """Max 25 Points: Repurposing need (10) + Editing/Turnaround (8) + Multi-channel publishing (7)."""
        score = 0
        notes = []
        need = str(lead.get("incubrix_need", "")).lower()
        segment = str(lead.get("creator_segment", "")).lower()

        # Repurposing & Shorts
        if any(k in need for k in ["repurpose", "short", "clip", "highlight", "reel", "tiktok"]):
            score += 10
            notes.append("Need for automated clip repurposing: +10")
        elif "podcaster" in segment or "video_first" in segment:
            score += 6
            notes.append("High intrinsic repurposing potential for video/audio: +6")

        # Editing & Turnaround
        if any(k in need for k in ["editing", "editor", "cut", "caption", "subtitle", "audio cleanup", "turnaround"]):
            score += 8
            notes.append("Explicit editing / captioning bottleneck: +8")

        # Consistency & Workflow
        if any(k in need for k in ["backlog", "consistency", "workflow", "publish", "scale", "team"]):
            score += 7
            notes.append("Backlog/multi-channel publishing pain: +7")

        if LeadValidator.is_valid_url(lead.get("need_evidence_url")) and score < 14:
            score = max(score, 14)
            notes.append("Documented IncuBrix need baseline: set to 14")

        score = min(25, score)
        return score, "; ".join(notes)

    def score_reachability(self, lead: Dict[str, Any]) -> Tuple[int, str]:
        """Max 15 Points: Direct Verified Email (12) + Backup Channel (3) OR LinkedIn/YouTube (10-12)."""
        score = 0
        notes = []
        ch = str(lead.get("best_channel", ""))

        if ch == "Email":
            score += 12
            notes.append("Direct verified business email: +12")
        elif ch == "LinkedIn":
            score += 10
            notes.append("Active professional LinkedIn channel: +10")
        elif ch == "YouTube Business Contact":
            score += 9
            notes.append("Public YouTube business inquiry: +9")
        else:
            score += 6
            notes.append(f"Public channel ({ch}): +6")

        if lead.get("backup_channel") and lead.get("backup_channel") != ch:
            score += 3
            notes.append(f"Verified secondary channel ({lead.get('backup_channel')}): +3")

        score = min(15, score)
        return score, "; ".join(notes)

    def score_evidence(self, lead: Dict[str, Any]) -> Tuple[int, str]:
        """Max 20 Points: 5 points for each verified public evidence link."""
        score = 0
        notes = []

        if LeadValidator.is_valid_url(lead.get("recent_content_url")):
            score += 5
            notes.append("Valid content link (+5)")
        if LeadValidator.is_valid_url(lead.get("monetization_evidence_url")):
            score += 5
            notes.append("Valid monetization link (+5)")
        if LeadValidator.is_valid_url(lead.get("need_evidence_url")):
            score += 5
            notes.append("Valid need link (+5)")
        if LeadValidator.is_valid_url(lead.get("channel_evidence_url")):
            score += 5
            notes.append("Valid contact link (+5)")

        return score, "; ".join(notes)

    def calculate_lead_score(self, lead: Dict[str, Any]) -> Dict[str, Any]:
        """Calculates 100-point transparent score with rubric explanation."""
        act_score, act_notes = self.score_activity(lead)
        com_score, com_notes = self.score_commercial(lead)
        fit_score, fit_notes = self.score_incubrix_fit(lead)
        rec_score, rec_notes = self.score_reachability(lead)
        evi_score, evi_notes = self.score_evidence(lead)

        total_score = act_score + com_score + fit_score + rec_score + evi_score

        explanation = (
            f"Activity: {act_score}/20 ({act_notes}) | "
            f"Commercial: {com_score}/20 ({com_notes}) | "
            f"ProductFit: {fit_score}/25 ({fit_notes}) | "
            f"Reachability: {rec_score}/15 ({rec_notes}) | "
            f"Evidence: {evi_score}/20 ({evi_notes})"
        )

        record = dict(lead)
        record["lead_score"] = total_score
        record["score_explanation"] = explanation
        return record

    def assign_priorities(self, leads: List[Dict[str, Any]], priority_a_cap: int = 25) -> List[Dict[str, Any]]:
        """
        Assigns Priority A, B, C:
          - Qualified leads sorted by score desc
          - Top 25 qualified leads receive Priority 'A'
          - Remaining qualified leads receive Priority 'B' (if score >= 65) or 'C'
          - Rejected leads are assigned 'C'
        """
        # Separate qualified from rejected
        qualified_leads = [l for l in leads if l.get("candidate_status") in ("QUALIFIED", "REAL_VERIFIED", "DEMO_SYNTHETIC")]
        rejected_leads = [l for l in leads if l.get("candidate_status") not in ("QUALIFIED", "REAL_VERIFIED", "DEMO_SYNTHETIC")]

        # Sort qualified: real verified creators prioritized, then sorted by lead_score descending
        qualified_leads.sort(
            key=lambda x: (
                1 if x.get("candidate_status") in ("QUALIFIED", "REAL_VERIFIED") and not x.get("is_demo") and "DEMO" not in str(x.get("lead_id", "")).upper() else 0,
                int(x.get("lead_score", 0))
            ),
            reverse=True
        )

        for i, lead in enumerate(qualified_leads):
            if i < priority_a_cap and int(lead.get("lead_score", 0)) >= 75:
                lead["priority"] = "A"
            elif int(lead.get("lead_score", 0)) >= 60:
                lead["priority"] = "B"
            else:
                lead["priority"] = "C"

        for lead in rejected_leads:
            lead["priority"] = "C"

        return qualified_leads + rejected_leads
