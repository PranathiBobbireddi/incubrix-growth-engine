"""
engine/validator.py
Comprehensive Lead Qualification Engine implementing Criteria A through F
and portfolio distribution constraints per IncuBrix assessment specifications.
"""

import re
from datetime import datetime
from typing import Dict, Any, Tuple, List, Optional
from urllib.parse import urlparse

from engine.logger import logger

# Approved parameters
APPROVED_SEGMENTS = {
    "podcaster", "video_podcaster", "youtuber", "video_first_creator",
    "coach", "consultant", "educator", "expert_creator", "podcast"
}

EXCLUDED_SEGMENTS = {
    "agency", "management_firm", "generic_brand", "publication", "directory", "fan_account",
    "media_agency", "talent_management", "aggregator"
}

APPROVED_COUNTRIES = {"US", "CA", "GB", "IE", "AU", "NZ", "SG"}
APPROVED_LANGUAGE = "en"
REFERENCE_DATE = "2026-11-23"

class LeadValidator:
    """Evaluates creator leads against strict Criteria A through F."""

    def __init__(self, reference_date: str = REFERENCE_DATE):
        self.reference_date = datetime.strptime(reference_date, "%Y-%m-%d")

    @staticmethod
    def is_valid_url(url: Optional[str]) -> bool:
        """Verifies if a string is a non-empty, well-formed HTTP/HTTPS URL."""
        if not url or not isinstance(url, str):
            return False
        url = url.strip()
        if not (url.startswith("http://") or url.startswith("https://")):
            return False
        try:
            parsed = urlparse(url)
            return bool(parsed.netloc and "." in parsed.netloc)
        except Exception:
            return False

    def check_criterion_a(self, lead: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Criterion A: Real and relevant
        Real individual creator in approved segment and approved country, official profile & stable ID.
        """
        segment = str(lead.get("creator_segment", "")).lower().strip().replace(" ", "_")
        if segment in EXCLUDED_SEGMENTS or any(ex in segment for ex in EXCLUDED_SEGMENTS):
            return False, f"Criterion A Failed: Excluded segment ({segment})"
        if segment not in APPROVED_SEGMENTS and not any(app in segment for app in APPROVED_SEGMENTS):
            return False, f"Criterion A Failed: Non-approved segment ({segment})"

        country = str(lead.get("country_iso2", "")).upper().strip()
        if country not in APPROVED_COUNTRIES:
            return False, f"Criterion A Failed: Non-approved country ({country})"

        lang = str(lead.get("primary_language", "")).lower().strip()
        if lang != APPROVED_LANGUAGE:
            return False, f"Criterion A Failed: Non-approved language ({lang})"

        profile_url = lead.get("profile_url", "").strip()
        if not self.is_valid_url(profile_url):
            return False, "Criterion A Failed: Invalid or missing profile_url"

        stable_id = str(lead.get("stable_creator_id", "")).strip()
        if not stable_id:
            return False, "Criterion A Failed: Missing stable_creator_id"

        creator_name = str(lead.get("creator_name", "")).strip()
        if not creator_name:
            return False, "Criterion A Failed: Missing creator_name"

        return True, "Passed Criterion A"

    def check_criterion_b(self, lead: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Criterion B: Active
        Either 8 content items in last 30d OR 2 long-form items in last 60d,
        AND last channel activity within 60 days.
        """
        last_date_str = str(lead.get("last_content_date", "")).strip()
        if not last_date_str:
            return False, "Criterion B Failed: Missing last_content_date"

        try:
            last_date = datetime.strptime(last_date_str, "%Y-%m-%d")
            days_inactive = (self.reference_date - last_date).days
            if days_inactive > 60:
                return False, f"Criterion B Failed: Inactive for {days_inactive} days (> 60 days threshold)"
        except ValueError:
            return False, f"Criterion B Failed: Malformed last_content_date ({last_date_str})"

        recent_url = lead.get("recent_content_url", "").strip()
        if not self.is_valid_url(recent_url):
            return False, "Criterion B Failed: Invalid or missing recent_content_url"

        try:
            count_30d = int(lead.get("content_count_30d", 0))
            longform_60d = int(lead.get("longform_count_60d", 0))
        except (ValueError, TypeError):
            return False, "Criterion B Failed: Malformed content frequency counts"

        if count_30d < 8 and longform_60d < 2:
            return False, f"Criterion B Failed: Content frequency below threshold (30d={count_30d} < 8 and 60d_longform={longform_60d} < 2)"

        return True, "Passed Criterion B"

    def check_criterion_c(self, lead: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Criterion C: Commercial
        Public evidence of sponsorship, product, service, course, membership, subscription, affiliate offer.
        """
        signal = str(lead.get("monetization_signal", "")).strip()
        if not signal:
            return False, "Criterion C Failed: Missing monetization_signal"

        evidence_url = lead.get("monetization_evidence_url", "").strip()
        if not self.is_valid_url(evidence_url):
            return False, "Criterion C Failed: Invalid or missing monetization_evidence_url"

        return True, "Passed Criterion C"

    def check_criterion_d(self, lead: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Criterion D: IncuBrix need
        Evidence of need in content creation, repurposing, editing, captions, publishing, consistency, backlog, or workflow.
        """
        need = str(lead.get("incubrix_need", "")).strip()
        if not need:
            return False, "Criterion D Failed: Missing incubrix_need description"

        need_url = lead.get("need_evidence_url", "").strip()
        if not self.is_valid_url(need_url):
            return False, "Criterion D Failed: Invalid or missing need_evidence_url"

        return True, "Passed Criterion D"

    def check_criterion_e(self, lead: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Criterion E: Reachable
        Channel is real, public, used for business contact, active in last 60 days. No guessed emails.
        """
        best_ch = str(lead.get("best_channel", "")).strip()
        valid_channels = {"Email", "LinkedIn", "YouTube Business Contact", "Instagram", "X"}
        if best_ch not in valid_channels:
            return False, f"Criterion E Failed: Non-standard best_channel ({best_ch})"

        handle_url = str(lead.get("channel_handle_or_url", "")).strip()
        if not handle_url:
            return False, "Criterion E Failed: Missing channel_handle_or_url"

        # Specific channel validations
        if best_ch == "Email":
            if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", handle_url):
                return False, f"Criterion E Failed: Invalid email format ({handle_url})"
        elif best_ch in {"LinkedIn", "YouTube Business Contact"}:
            if not self.is_valid_url(handle_url):
                return False, f"Criterion E Failed: Invalid channel URL ({handle_url})"

        ch_evidence = lead.get("channel_evidence_url", "").strip()
        if not self.is_valid_url(ch_evidence):
            return False, "Criterion E Failed: Invalid or missing channel_evidence_url"

        return True, "Passed Criterion E"

    def check_criterion_f(self, lead: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Criterion F: Complete and unique
        All required fields complete, checked within last 30 days.
        """
        checked_str = str(lead.get("checked_date", "")).strip()
        if not checked_str:
            return False, "Criterion F Failed: Missing checked_date"

        try:
            checked_dt = datetime.strptime(checked_str, "%Y-%m-%d")
            age = (self.reference_date - checked_dt).days
            if age > 30:
                return False, f"Criterion F Failed: Evidence check is stale ({age} days old > 30 days)"
        except ValueError:
            return False, f"Criterion F Failed: Malformed checked_date ({checked_str})"

        # Verify no missing mandatory text attributes
        mandatory_cols = [
            "lead_id", "creator_name", "creator_segment", "country_iso2", "primary_platform",
            "profile_url", "stable_creator_id", "last_content_date", "recent_content_url",
            "monetization_signal", "monetization_evidence_url", "incubrix_need",
            "need_evidence_url", "best_channel", "channel_handle_or_url", "channel_evidence_url"
        ]
        for col in mandatory_cols:
            if not str(lead.get(col, "")).strip():
                return False, f"Criterion F Failed: Missing mandatory field '{col}'"

        return True, "Passed Criterion F"

    def evaluate_lead(self, lead: Dict[str, Any]) -> Dict[str, Any]:
        """
        Runs Criteria A through F. Sets candidate_status, rejection_reason, and completeness_check.
        """
        record = dict(lead)
        checks = [
            ("A", self.check_criterion_a),
            ("B", self.check_criterion_b),
            ("C", self.check_criterion_c),
            ("D", self.check_criterion_d),
            ("E", self.check_criterion_e),
            ("F", self.check_criterion_f),
        ]

        failed_reasons = []
        for name, check_fn in checks:
            passed, reason = check_fn(record)
            if not passed:
                failed_reasons.append(reason)

        if failed_reasons:
            record["candidate_status"] = "REJECTED"
            record["rejection_reason"] = " | ".join(failed_reasons)
            record["completeness_check"] = "FAILED"
            record["data_tier"] = "REJECTED"
        elif "PENDING" in str(record.get("lead_id", "")).upper() or record.get("candidate_status") == "PENDING_VERIFICATION" or not record.get("channel_handle_or_url"):
            record["candidate_status"] = "PENDING_VERIFICATION"
            record["rejection_reason"] = "PENDING_VERIFICATION: Awaiting creator business contact confirmation / API access"
            record["completeness_check"] = "PENDING"
            record["data_tier"] = "PENDING_VERIFICATION"
        elif record.get("is_demo") or "DEMO" in str(record.get("lead_id", "")).upper() or "SYNTHETIC" in str(record.get("lead_id", "")).upper():
            record["candidate_status"] = "DEMO_SYNTHETIC"
            record["rejection_reason"] = "SYNTHETIC_DATA_DEMO"
            record["completeness_check"] = "DEMO_VERIFIED"
            record["data_tier"] = "DEMO_SYNTHETIC"
        else:
            record["candidate_status"] = "QUALIFIED"
            record["rejection_reason"] = ""
            record["completeness_check"] = "VERIFIED"
            record["data_tier"] = "REAL_VERIFIED"

        return record

    @staticmethod
    def audit_portfolio_constraints(leads: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Checks macro constraints over a portfolio of qualified leads:
        - At least 80% from approved countries
        - At least 3 distinct countries
        - No single country exceeding 60%
        """
        qualified = [l for l in leads if l.get("candidate_status") in ("QUALIFIED", "REAL_VERIFIED", "DEMO_SYNTHETIC")]
        total = len(qualified)
        if total == 0:
            return {
                "valid": False,
                "total_qualified": 0,
                "approved_country_ratio": 0.0,
                "distinct_countries": 0,
                "max_single_country_ratio": 0.0,
                "reasons": ["No qualified leads in batch"]
            }

        counts = {}
        approved_count = 0
        for l in qualified:
            c = str(l.get("country_iso2", "")).upper()
            counts[c] = counts.get(c, 0) + 1
            if c in APPROVED_COUNTRIES:
                approved_count += 1

        approved_ratio = approved_count / total
        distinct_count = len(counts)
        max_ratio = max(counts.values()) / total if counts else 0.0
        dominant_country = max(counts, key=counts.get) if counts else "None"

        reasons = []
        if approved_ratio < 0.80:
            reasons.append(f"Approved country ratio {approved_ratio:.1%} is below 80% requirement")
        if distinct_count < 3:
            reasons.append(f"Only {distinct_count} distinct countries represented (requires at least 3)")
        if max_ratio > 0.60:
            reasons.append(f"Country {dominant_country} represents {max_ratio:.1%}, exceeding 60% ceiling")

        return {
            "valid": len(reasons) == 0,
            "total_qualified": total,
            "approved_country_ratio": round(approved_ratio, 4),
            "distinct_countries": distinct_count,
            "dominant_country": dominant_country,
            "max_single_country_ratio": round(max_ratio, 4),
            "country_distribution": counts,
            "violations": reasons
        }
