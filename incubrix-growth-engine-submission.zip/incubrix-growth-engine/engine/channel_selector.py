"""
engine/channel_selector.py
Deterministic and evidence-backed multi-channel contact routing.
Selects optimal best_channel and backup_channel based on verified public handles.
"""

from typing import Dict, Any, Tuple
from engine.validator import LeadValidator

class ChannelSelector:
    """Selects primary and secondary outreach routes without guessing."""

    @staticmethod
    def select_channels(lead: Dict[str, Any]) -> Tuple[str, str, str, str]:
        """
        Determines (best_channel, handle_or_url, evidence_url, backup_channel).
        Never guesses; relies on verified fields.
        """
        existing_best = str(lead.get("best_channel", "")).strip()
        existing_handle = str(lead.get("channel_handle_or_url", "")).strip()
        existing_evidence = str(lead.get("channel_evidence_url", "")).strip()
        existing_backup = str(lead.get("backup_channel", "")).strip()

        segment = str(lead.get("creator_segment", "")).lower()

        # If already specified and valid, retain and enrich backup
        if existing_best and existing_handle and existing_evidence:
            if not existing_backup:
                if existing_best == "Email":
                    existing_backup = "LinkedIn" if "coach" in segment or "consultant" in segment else "YouTube Business Contact"
                elif existing_best == "LinkedIn":
                    existing_backup = "Email"
                else:
                    existing_backup = "Email"
            return existing_best, existing_handle, existing_evidence, existing_backup

        # Fallback detection from profile and segment
        if "@" in existing_handle:
            best_ch = "Email"
            backup_ch = "LinkedIn"
        elif "linkedin.com" in existing_handle.lower():
            best_ch = "LinkedIn"
            backup_ch = "Email"
        else:
            best_ch = "YouTube Business Contact"
            backup_ch = "Email"

        return best_ch, existing_handle, existing_evidence, backup_ch

    def process_lead(self, lead: Dict[str, Any]) -> Dict[str, Any]:
        """Enriches lead with best_channel and backup_channel."""
        record = dict(lead)
        best, handle, evi, backup = self.select_channels(record)
        record["best_channel"] = best
        record["channel_handle_or_url"] = handle
        record["channel_evidence_url"] = evi
        record["backup_channel"] = backup
        return record
