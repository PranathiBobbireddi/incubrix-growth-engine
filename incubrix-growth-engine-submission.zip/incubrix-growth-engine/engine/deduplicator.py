"""
engine/deduplicator.py
Robust cross-source deduplication and evidence merging engine.
Prevents duplicate creator entries while synthesizing multi-source signals.
"""

import re
from typing import List, Dict, Any, Tuple
from urllib.parse import urlparse

from engine.logger import logger

class LeadDeduplicator:
    """
    Deduplicates records across:
      1. Primary Key: Platform + stable_creator_id
      2. Secondary Key: Canonical profile_url
      3. Tertiary Key: Normalized creator_name + platform
    Merges evidence from duplicates into a unified master record.
    """

    @staticmethod
    def canonical_url(url: str) -> str:
        """Strips trailing slashes, protocol variations, www, and query params."""
        if not url or not isinstance(url, str):
            return ""
        url = url.strip().lower()
        # Remove query parameters and fragments for canonical identity
        url = url.split("?")[0].split("#")[0]
        # Remove trailing slash
        url = url.rstrip("/")
        # Normalize protocol & www
        url = re.sub(r"^https?://(www\.)?", "", url)
        return url

    @staticmethod
    def normalize_name(name: str) -> str:
        """Normalizes creator name by removing punctuation and extra whitespace."""
        if not name:
            return ""
        name = re.sub(r"[^\w\s]", "", str(name).lower())
        return " ".join(name.split())

    def merge_records(self, primary: Dict[str, Any], duplicate: Dict[str, Any]) -> Dict[str, Any]:
        """Merges evidence from duplicate into primary record."""
        merged = dict(primary)

        # 1. Update numeric metrics to maximum observed
        for metric in ["followers_or_subscribers", "content_count_30d", "longform_count_60d"]:
            try:
                p_val = int(merged.get(metric, 0))
                d_val = int(duplicate.get(metric, 0))
                merged[metric] = max(p_val, d_val)
            except (ValueError, TypeError):
                pass

        # 2. Pick most recent content date
        p_date = str(merged.get("last_content_date", "")).strip()
        d_date = str(duplicate.get("last_content_date", "")).strip()
        if d_date and (not p_date or d_date > p_date):
            merged["last_content_date"] = d_date
            if duplicate.get("recent_content_url"):
                merged["recent_content_url"] = duplicate["recent_content_url"]

        # 3. Fill missing contact or channel fields
        if not merged.get("channel_handle_or_url") and duplicate.get("channel_handle_or_url"):
            merged["best_channel"] = duplicate.get("best_channel", merged.get("best_channel"))
            merged["channel_handle_or_url"] = duplicate.get("channel_handle_or_url")
            merged["channel_evidence_url"] = duplicate.get("channel_evidence_url", merged.get("channel_evidence_url"))

        if not merged.get("backup_channel") and duplicate.get("backup_channel"):
            merged["backup_channel"] = duplicate.get("backup_channel")

        # 4. Fill missing monetization / need evidence
        if not merged.get("monetization_evidence_url") and duplicate.get("monetization_evidence_url"):
            merged["monetization_signal"] = duplicate.get("monetization_signal", merged.get("monetization_signal"))
            merged["monetization_evidence_url"] = duplicate.get("monetization_evidence_url")

        if not merged.get("need_evidence_url") and duplicate.get("need_evidence_url"):
            merged["incubrix_need"] = duplicate.get("incubrix_need", merged.get("incubrix_need"))
            merged["need_evidence_url"] = duplicate.get("need_evidence_url")

        # 5. Tag duplicate merge status
        merged["duplicate_check"] = "PASSED_MERGED"

        return merged

    def deduplicate(self, leads: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], int]:
        """
        Executes multi-key deduplication and returns (deduped_leads, duplicates_removed_count).
        """
        unique_leads: List[Dict[str, Any]] = []
        primary_key_map: Dict[str, int] = {}    # platform:stable_id -> index in unique_leads
        secondary_key_map: Dict[str, int] = {}  # canonical_url -> index
        tertiary_key_map: Dict[str, int] = {}   # norm_name:platform -> index

        duplicates_count = 0

        for lead in leads:
            platform = str(lead.get("primary_platform", "")).lower().strip()
            stable_id = str(lead.get("stable_creator_id", "")).strip()
            profile_url = lead.get("profile_url", "")
            canon_url = self.canonical_url(profile_url)
            norm_name = self.normalize_name(lead.get("creator_name", ""))

            pk = f"{platform}:{stable_id}" if (platform and stable_id) else None
            sk = canon_url if (canon_url and len(canon_url) > 5) else None
            tk = f"{norm_name}:{platform}" if (norm_name and platform) else None

            match_idx = None
            if pk and pk in primary_key_map:
                match_idx = primary_key_map[pk]
            elif sk and sk in secondary_key_map:
                match_idx = secondary_key_map[sk]
            elif tk and tk in tertiary_key_map:
                match_idx = tertiary_key_map[tk]

            if match_idx is not None:
                # Merge duplicate into existing record
                duplicates_count += 1
                existing_lead = unique_leads[match_idx]
                merged = self.merge_records(existing_lead, lead)
                unique_leads[match_idx] = merged
            else:
                new_lead = dict(lead)
                if not new_lead.get("duplicate_check"):
                    new_lead["duplicate_check"] = "PASSED"
                
                idx = len(unique_leads)
                unique_leads.append(new_lead)

                if pk:
                    primary_key_map[pk] = idx
                if sk:
                    secondary_key_map[sk] = idx
                if tk:
                    tertiary_key_map[tk] = idx

        logger.info(f"Deduplication complete: {len(leads)} input -> {len(unique_leads)} unique ({duplicates_count} duplicates merged/removed)")
        return unique_leads, duplicates_count
