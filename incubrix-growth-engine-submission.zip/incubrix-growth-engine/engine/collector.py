"""
engine/collector.py
Multi-channel lead collection, streaming ingestion, and schema normalization.
Supports CSV streaming, JSON sources, and optional YouTube Data API v3 live queries.
"""

import os
import csv
import json
import logging
from typing import Generator, List, Dict, Any, Optional
import pandas as pd

from engine.logger import logger, log_error_event

CANONICAL_COLUMNS = [
    "lead_id", "creator_name", "creator_segment", "country_iso2", "primary_language",
    "primary_platform", "profile_url", "stable_creator_id", "followers_or_subscribers",
    "last_content_date", "recent_content_url", "content_count_30d", "longform_count_60d",
    "monetization_signal", "monetization_evidence_url", "incubrix_need", "need_evidence_url",
    "best_channel", "channel_handle_or_url", "channel_evidence_url", "backup_channel",
    "personalization_hook", "first_message", "checked_date", "priority", "lead_score",
    "candidate_status", "rejection_reason", "duplicate_check", "completeness_check"
]

class LeadCollector:
    """Handles ingestion, normalization, and streaming of creator candidate leads."""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        self.source_registry = {
            "csv": self.load_from_csv,
            "json": self.load_from_json,
            "youtube_api": self.fetch_from_youtube_api
        }

    @staticmethod
    def normalize_record(raw: Dict[str, Any]) -> Dict[str, Any]:
        """Normalizes raw input keys, strips whitespace, and establishes defaults."""
        normalized = {}
        for col in CANONICAL_COLUMNS:
            val = raw.get(col, "")
            if pd.isna(val) or val is None:
                val = ""
            elif isinstance(val, float) and val.is_integer():
                val = int(val)
            elif isinstance(val, str):
                val = val.strip()
            normalized[col] = val

        # Handle numeric conversions
        for num_field in ["followers_or_subscribers", "content_count_30d", "longform_count_60d", "lead_score"]:
            v = normalized.get(num_field)
            if v == "" or v is None:
                normalized[num_field] = 0
            else:
                try:
                    normalized[num_field] = int(float(v))
                except (ValueError, TypeError):
                    normalized[num_field] = 0

        # Enforce uppercase ISO country and lowercase language
        if normalized["country_iso2"]:
            normalized["country_iso2"] = str(normalized["country_iso2"]).upper()
        if normalized["primary_language"]:
            normalized["primary_language"] = str(normalized["primary_language"]).lower()

        # Handle source tags
        if "is_demo" not in normalized:
            is_demo = "DEMO" in str(normalized.get("lead_id", "")).upper() or "DEMO" in str(normalized.get("creator_name", "")).upper()
            normalized["is_demo"] = is_demo

        return normalized

    def load_from_csv(self, file_path: str) -> List[Dict[str, Any]]:
        """Reads CSV file and returns normalized records."""
        if not os.path.exists(file_path):
            logger.warning(f"Collector file not found: {file_path}")
            return []
        
        try:
            df = pd.read_csv(file_path, dtype=str, keep_default_na=False, encoding="utf-8")
        except UnicodeDecodeError:
            df = pd.read_csv(file_path, dtype=str, keep_default_na=False, encoding="latin1")

        records = [self.normalize_record(row) for row in df.to_dict(orient="records")]
        logger.info(f"Loaded {len(records)} records from {file_path}")
        return records

    def stream_from_csv(self, file_path: str, batch_size: int = 500) -> Generator[List[Dict[str, Any]], None, None]:
        """Streams records in manageable memory-safe chunks for 1,000+ to 5,000+ scales."""
        if not os.path.exists(file_path):
            logger.error(f"Cannot stream non-existent file: {file_path}")
            return

        batch = []
        with open(file_path, mode="r", encoding="utf-8", errors="replace") as f:
            reader = csv.DictReader(f)
            for row in reader:
                batch.append(self.normalize_record(row))
                if len(batch) >= batch_size:
                    yield batch
                    batch = []
            if batch:
                yield batch

    def load_from_json(self, file_path: str) -> List[Dict[str, Any]]:
        """Reads JSON records file and normalizes fields."""
        if not os.path.exists(file_path):
            return []
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        records = [self.normalize_record(r) for r in data]
        return records

    def fetch_from_youtube_api(self, query: str, max_results: int = 25, api_key: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Queries official YouTube Data API v3 if API key is provided.
        Falls back cleanly with warning when key is missing or quota exceeded.
        """
        api_key = api_key or os.environ.get("YOUTUBE_API_KEY")
        if not api_key:
            logger.info("YOUTUBE_API_KEY not configured. Skipping live YouTube API fetch and using vetted local cache.")
            return []

        try:
            from googleapiclient.discovery import build
            youtube = build("youtube", "v3", developerKey=api_key)
            req = youtube.search().list(
                q=query,
                part="snippet",
                type="channel",
                maxResults=min(max_results, 50)
            )
            res = req.execute()
            items = res.get("items", [])
            results = []
            for item in items:
                ch_id = item["snippet"]["channelId"]
                title = item["snippet"]["channelTitle"]
                rec = {
                    "lead_id": f"YT_{ch_id[:8]}",
                    "creator_name": title,
                    "creator_segment": "youtuber",
                    "primary_platform": "YouTube",
                    "profile_url": f"https://www.youtube.com/channel/{ch_id}",
                    "stable_creator_id": ch_id,
                    "primary_language": "en"
                }
                results.append(self.normalize_record(rec))
            return results
        except Exception as e:
            logger.warning(f"YouTube API call failed: {e}. Falling back cleanly.")
            log_error_event("COLLECTOR", "YOUTUBE_API_ERROR", "collector.py", str(e))
            return []
