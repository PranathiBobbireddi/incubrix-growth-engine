"""
engine/logger.py
Logging and SQLite telemetry infrastructure for IncuBrix Growth Engine.
Tracks pipeline execution, performance benchmarks, error traces, and seed outreach simulations.
"""

import os
import sys
import sqlite3
import logging
from datetime import datetime
from typing import Optional, Dict, Any, List

DEFAULT_DB_PATH = os.path.join("logs", "engine_history.db")
DEFAULT_LOG_PATH = os.path.join("logs", "engine.log")

def setup_logger(name: str = "IncuBrixEngine", log_file: str = DEFAULT_LOG_PATH, level: int = logging.INFO) -> logging.Logger:
    """Configures multi-handler logger writing to console and persistent log file."""
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    if not logger.handlers:
        # File handler
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setLevel(level)
        file_format = logging.Formatter(
            fmt="%(asctime)s [%(levelname)s] [%(name)s] %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        file_handler.setFormatter(file_format)
        logger.addHandler(file_handler)
        
        # Console handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(level)
        console_format = logging.Formatter(
            fmt="[%(levelname)s] %(message)s"
        )
        console_handler.setFormatter(console_format)
        logger.addHandler(console_handler)
        
    return logger

logger = setup_logger()

def get_db_connection(db_path: str = DEFAULT_DB_PATH) -> sqlite3.Connection:
    """Establishes SQLite connection with row factory."""
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def init_db(db_path: str = DEFAULT_DB_PATH):
    """Initializes tables for run telemetry, lead audits, and seed simulations."""
    with get_db_connection(db_path) as conn:
        cursor = conn.cursor()
        
        # Runs history table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS runs (
                run_id TEXT PRIMARY KEY,
                run_type TEXT NOT NULL,
                started_at TEXT NOT NULL,
                ended_at TEXT,
                duration_seconds REAL,
                input_count INTEGER DEFAULT 0,
                items_produced INTEGER DEFAULT 0,
                qualified_count INTEGER DEFAULT 0,
                rejected_count INTEGER DEFAULT 0,
                duplicates_removed INTEGER DEFAULT 0,
                status TEXT NOT NULL,
                error_message TEXT,
                direct_cost_usd REAL DEFAULT 0.0,
                notes TEXT
            )
        """)
        
        # Seed test outreach log table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS seed_outreach_events (
                event_id TEXT PRIMARY KEY,
                run_id TEXT,
                lead_id TEXT NOT NULL,
                creator_name TEXT NOT NULL,
                channel TEXT NOT NULL,
                recipient_handle TEXT NOT NULL,
                subject_or_summary TEXT,
                tracking_link TEXT,
                status TEXT NOT NULL,
                response_received TEXT,
                error_details TEXT,
                timestamp TEXT NOT NULL
            )
        """)
        
        # Run error logs table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS error_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id TEXT,
                error_type TEXT,
                module TEXT,
                message TEXT,
                timestamp TEXT NOT NULL
            )
        """)
        
        conn.commit()

def record_run(
    run_id: str,
    run_type: str,
    started_at: str,
    ended_at: Optional[str] = None,
    duration_seconds: Optional[float] = None,
    input_count: int = 0,
    items_produced: int = 0,
    qualified_count: int = 0,
    rejected_count: int = 0,
    duplicates_removed: int = 0,
    status: str = "SUCCESS",
    error_message: Optional[str] = None,
    direct_cost_usd: float = 0.0,
    notes: Optional[str] = None,
    db_path: str = DEFAULT_DB_PATH
):
    """Inserts or updates a run execution summary."""
    init_db(db_path)
    with get_db_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT OR REPLACE INTO runs (
                run_id, run_type, started_at, ended_at, duration_seconds,
                input_count, items_produced, qualified_count, rejected_count,
                duplicates_removed, status, error_message, direct_cost_usd, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            run_id, run_type, started_at, ended_at, duration_seconds,
            input_count, items_produced, qualified_count, rejected_count,
            duplicates_removed, status, error_message, direct_cost_usd, notes
        ))
        conn.commit()

def log_error_event(run_id: str, module: str, error_type: str, message: str, db_path: str = DEFAULT_DB_PATH):
    """Logs runtime error into SQLite error_logs table."""
    init_db(db_path)
    with get_db_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO error_logs (run_id, error_type, module, message, timestamp)
            VALUES (?, ?, ?, ?, ?)
        """, (run_id, error_type, module, message, datetime.now().isoformat()))
        conn.commit()

def log_seed_event(
    event_id: str,
    run_id: str,
    lead_id: str,
    creator_name: str,
    channel: str,
    recipient_handle: str,
    subject_or_summary: str,
    tracking_link: str,
    status: str,
    response_received: Optional[str] = None,
    error_details: Optional[str] = None,
    db_path: str = DEFAULT_DB_PATH
):
    """Records a single simulated seed outreach event."""
    init_db(db_path)
    with get_db_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT OR REPLACE INTO seed_outreach_events (
                event_id, run_id, lead_id, creator_name, channel,
                recipient_handle, subject_or_summary, tracking_link,
                status, response_received, error_details, timestamp
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            event_id, run_id, lead_id, creator_name, channel,
            recipient_handle, subject_or_summary, tracking_link,
            status, response_received, error_details, datetime.now().isoformat()
        ))
        conn.commit()

def get_all_runs(db_path: str = DEFAULT_DB_PATH) -> List[Dict[str, Any]]:
    """Retrieves all historic runs from database."""
    init_db(db_path)
    with get_db_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM runs ORDER BY started_at DESC")
        return [dict(row) for row in cursor.fetchall()]

def get_seed_logs(db_path: str = DEFAULT_DB_PATH) -> List[Dict[str, Any]]:
    """Retrieves seed test event log history."""
    init_db(db_path)
    with get_db_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM seed_outreach_events ORDER BY timestamp DESC")
        return [dict(row) for row in cursor.fetchall()]
