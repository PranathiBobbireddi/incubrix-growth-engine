"""
engine/refresh.py
Repeatable refresh engine and failure recovery orchestrator.
Merges incremental creator data, updates existing records, rejects duplicates, and logs benchmarks.
"""

import os
import time
from datetime import datetime
from typing import Dict, Any, List, Tuple, Optional

from engine.logger import logger, record_run, log_error_event
from engine.collector import LeadCollector
from engine.validator import LeadValidator
from engine.deduplicator import LeadDeduplicator
from engine.scoring import LeadScorer
from engine.channel_selector import ChannelSelector
from engine.outreach_generator import OutreachGenerator
from engine.exporter import LeadExporter

class RefreshEngine:
    """Manages incremental data refresh, deduplication against existing database, and error recovery."""

    def __init__(self, master_csv_path: str = "data/output/leads.csv"):
        self.master_csv_path = master_csv_path
        self.collector = LeadCollector()
        self.validator = LeadValidator()
        self.deduplicator = LeadDeduplicator()
        self.scorer = LeadScorer()
        self.channel_selector = ChannelSelector()
        self.outreach_gen = OutreachGenerator()
        self.exporter = LeadExporter()

    def run_refresh(self, new_input_path: str, run_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Ingests incremental leads, deduplicates against existing leads,
        updates records with fresher evidence, scores, and re-exports cleanly.
        """
        start_time = time.time()
        start_iso = datetime.now().isoformat()
        run_id = run_id or f"REFRESH_{int(start_time)}"

        logger.info(f"Starting refresh run {run_id} from {new_input_path}")

        # 1. Load existing master records if file exists
        existing_leads = []
        if os.path.exists(self.master_csv_path):
            existing_leads = self.collector.load_from_csv(self.master_csv_path)
            logger.info(f"Loaded {len(existing_leads)} existing master records.")

        # 2. Ingest incoming records with failure recovery
        if not os.path.exists(new_input_path):
            err_msg = f"Input file not found: {new_input_path}"
            logger.error(err_msg)
            log_error_event(run_id, "refresh.py", "FILE_NOT_FOUND", err_msg)
            record_run(
                run_id=run_id,
                run_type="REFRESH",
                started_at=start_iso,
                ended_at=datetime.now().isoformat(),
                duration_seconds=round(time.time() - start_time, 2),
                status="FAILED",
                error_message=err_msg
            )
            return {"status": "FAILED", "error": err_msg}

        try:
            new_leads = self.collector.load_from_csv(new_input_path)
        except Exception as e:
            err_msg = f"Failed to ingest input file: {e}"
            logger.error(err_msg)
            log_error_event(run_id, "refresh.py", "FILE_READ_ERROR", err_msg)
            record_run(
                run_id=run_id,
                run_type="REFRESH",
                started_at=start_iso,
                ended_at=datetime.now().isoformat(),
                duration_seconds=round(time.time() - start_time, 2),
                status="FAILED",
                error_message=err_msg
            )
            return {"status": "FAILED", "error": err_msg}

        total_input_count = len(new_leads)

        # 3. Validate new records
        validated_new = []
        rejected_count = 0
        for l in new_leads:
            try:
                v = self.validator.evaluate_lead(l)
                if v.get("candidate_status") in ("QUALIFIED", "REAL_VERIFIED", "DEMO_SYNTHETIC"):
                    validated_new.append(v)
                else:
                    rejected_count += 1
            except Exception as e:
                rejected_count += 1
                log_error_event(run_id, "refresh.py", "VALIDATION_ERROR", f"Error on lead {l.get('lead_id')}: {e}")

        # 4. Combine existing master leads and new qualified leads, then deduplicate
        combined_pool = existing_leads + validated_new
        deduped_leads, duplicates_removed = self.deduplicator.deduplicate(combined_pool)

        # 5. Route channels and calculate scores
        scored_leads = []
        for l in deduped_leads:
            l = self.channel_selector.process_lead(l)
            l = self.scorer.calculate_lead_score(l)
            scored_leads.append(l)

        # 6. Assign priorities
        prioritized_leads = self.scorer.assign_priorities(scored_leads, priority_a_cap=25)

        # 7. Generate outreach for Priority A leads
        final_leads = []
        for l in prioritized_leads:
            if l.get("priority") == "A":
                l = self.outreach_gen.enrich_priority_a_lead(l)
            final_leads.append(l)

        # 8. Re-export clean CSVs
        export_paths = self.exporter.export_all_bundles(final_leads)
        wb_leads = self.collector.load_from_csv(export_paths["leads"])
        if not wb_leads and os.path.exists(export_paths.get("demo_leads", "")):
            wb_leads = self.collector.load_from_csv(export_paths["demo_leads"])
        if not wb_leads:
            wb_leads = final_leads
        self.exporter.build_submission_workbook(wb_leads, "submission_workbook.xlsx")

        duration = round(time.time() - start_time, 2)
        end_iso = datetime.now().isoformat()

        qualified_count = len([l for l in final_leads if l.get("candidate_status") in ("QUALIFIED", "REAL_VERIFIED", "DEMO_SYNTHETIC")])

        # 9. Log run summary to SQLite
        record_run(
            run_id=run_id,
            run_type="REFRESH",
            started_at=start_iso,
            ended_at=end_iso,
            duration_seconds=duration,
            input_count=total_input_count,
            items_produced=len(final_leads),
            qualified_count=qualified_count,
            rejected_count=rejected_count,
            duplicates_removed=duplicates_removed,
            status="SUCCESS",
            direct_cost_usd=0.0,
            notes=f"Incremental refresh merged into {self.master_csv_path}"
        )

        logger.info(f"Refresh run {run_id} completed successfully in {duration}s.")
        return {
            "status": "SUCCESS",
            "run_id": run_id,
            "duration_seconds": duration,
            "input_count": total_input_count,
            "items_produced": len(final_leads),
            "qualified_count": qualified_count,
            "rejected_count": rejected_count,
            "duplicates_removed": duplicates_removed,
            "export_paths": export_paths
        }
